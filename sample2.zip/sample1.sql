select * from Prod_16047;


create table cust_16047(
   cid number(4),
   custname varchar(50),
   custemail varchar(50),
   custmob number(10),
   custaddr varchar(50),
   custcountry varchar(50),
   custpass varchar(50),
   custsecans varchar(50)
);
alter table cust_16047 add custtype varchar(40);
delete from cust_16047;
create or replace procedure storecustinfo_16047 ( cname in varchar , cemail in varchar , cmob in varchar, caddr in varchar, ccountry in varchar , cpass in varchar , csecans in varchar ) as
cid number(4);
begin
  select count(*) into cid from cust_16047;
  cid:=cid+1;
  insert into cust_16047 values(cid,cname,cemail,cmob,caddr,ccountry,cpass,csecans,'User');
  commit;
end storecustinfo_16047;  

create or replace procedure verifyemailpass_16047 ( email in varchar , pass in varchar,flag out number,ctype out varchar ) as
custid number(4);
begin
  select custtype into ctype from cust_16047 where custemail=email and custpass=pass;
  flag:=1;
Exception
  when NO_DATA_FOUND then
  begin
     flag:=0;
     ctype:=null;
  end;   
end verifyemailpass_16047;     

create or replace procedure forgotpassproc_16047 ( email in varchar, secans in varchar , pass out varchar ) as
begin
  select custpass into pass from cust_16047 where custemail=email and custsecans=secans;
Exception
  when NO_DATA_FOUND then
     pass:=null;
end forgotpassproc_16047;  

delete from cust_16047;

create or replace procedure getcid_16047 ( custid out number , email in varchar , pass in varchar) as
begin
   select cid into custid from cust_16047 where custemail=email and custpass=pass;
end getcid_16047;   

select * from cust_16047;

delete from cust_16047;

create table paymentcard_16047 (
   cardname varchar(40),
   cardnumber number(20),
   carddate date,
   cardcode number(4),
   balance number(11,2)
);
drop table paymentcard_16047;
insert into paymentcard_16047 values('prasad karanjkar',501001052,TO_DATE('21-OCT-2025'),1111,45000);
select * from paymentcard_16047;

create or replace procedure verifypayinfo_16047( cname in varchar , cnum in number  , ccode in number , cbalance in number , flag out number) as
ccount number;
begin
  select balance into ccount from paymentcard_16047 where cardname=cname and cardnumber=cnum and cardcode=ccode;
  if ccount>=cbalance then
    flag:=1;
  else
    flag:=0;
  end if;
end verifypayinfo_16047;  

create table productcustinfo_16047 (
   custid number(4) references cust_16047(cid),
   prodname varchar(40),
   prodquantity number(4),
   prodrate number(4),
   prodamountsum number(5)

);
delete from productcustinfo_16047;
delete from cust_16047;
alter table cust_16047 add primary key(cid);
insert into cust_16047 values(1,'prasad','prasadpk95@gmail.com',9960750318,'55 shriram nagar','India','hello','Jalna','Admin');
create or replace procedure addproductinfo_16047 ( cid in number , pname in varchar , pquantity in number , prate in number , pamountsum in number ) as
begin
  insert into productcustinfo_16047 values(cid,pname,pquantity,prate,pamountsum);
end addproductinfo_16047;  
select * from productcustinfo_16047;


create or replace procedure addproduct_16047 ( pname in varchar , pdesc in varchar2 , prate in number , flag out number ) as
begin
  insert into Productinfo_16047 values(pname,pdesc,prate);
  flag:=1;
end addproduct_16047; 

create table Productinfo_16047 
(
  prodname varchar(40),
  proddesc varchar2(4000),
  prodrate number(5)
);

select * from cust_16047;
select * from Productinfo_16047;

delete from Productinfo_16047;

insert into Productinfo_16047 values('CHRYSOPERLA CARNEA','Chrysoperla carnea, known as the common green lacewing, is an insect in the Chrysopidae family. It is found in many parts of America, Europe and Asia. Although the adults feed on nectar, pollen and aphid honeydew, the larvae are active predators and feed on aphids and other small insects. It has been used in the biological control of insect pests on crops.

Chrysoperla carnea was originally considered to be a single species with a holarctic distribution but it has now been shown to be a complex of many cryptic, sibling subspecies. These are indistinguishable from each other morphologically but can be recognised by variations in the vibrational songs the insects use to communicat0e with each other, which they especially do during courtship.',200);
insert into Productinfo_16047 values('TRICHORAMMA CHILONIS','  Trichogramma is an small insect wasp belongs to a category of egg parasitoid biological agent.It is most widely used biocontrol agent in the world. It is an egg parasite and effective against bollworms of cotton , stem borers of rice, sorghum, maize and shoot borers of sugarcane, fruit borers on fruits and vegetables crops. It attacks and kills the pest at the egg stage itself and hence damage done by larvae on the crop parts is avoided. It is a low cost plant protection in comparison to pesticides for getting similar or better results without disturbing ecosystem balance.

',60);

create or replace procedure getallproduct_16047 ( prod out sys_refcursor ) as
begin
  open prod for select * from Productinfo_16047;
end getallproduct_16047;  