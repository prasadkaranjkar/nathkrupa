create table myproduct_16047(
id varchar(5) primary key,
pname varchar(40),
pqty number(4),
prate number(9,2),
amount number(9,2)
);
select * from Prod_16047;
select * from myproduct_16047;


create table Product_16047(
  product_id number(4) primary key,
  product_description varchar(15),
  price number(9,2)
);

create table customer_16047 (
  cust_id number(4) primary key,
  cust_name varchar2(40),
  email varchar2(40),
  mobile number(10),
  address varchar2(50)
);

create table product_order_16047 (
  ord_no number(4) primary key,
  product_id number(4),
  cust_id number(4),
  quantity number(3),
  order_date date
);
drop table customer_16047;
desc customer_16047;

insert into Product_16047 values(2,'electronic',70000);

insert into customer_16047 values(12,'saharsh','bsaharsh95@gmail.com',9960750454,'narendra nagar nagpur');

insert into product_order_16047 values(21,1,11,20,TO_DATE('21-JAN-2017'));


create or replace procedure custproc_16047 (p_id in number ) as
  custid number;
  custname varchar2(50);
  em varchar2(50);
  mob varchar2(50);
  addr varchar2(60);
begin
  select cust_id into custid from product_order_16047 where product_id=p_id;
  select cust_name,email,mobile,address into custname,em,mob,addr from customer_16047 where cust_id=custid;
  dbms_output.put_line(p_id||' '||custname||' '||em||' '||mob||' '||addr);
exception
  when NO_DATA_FOUND then
    dbms_output.put_line('Product with an id '||p_id||' doesnt exist');
end custproc_16047;    
set serveroutput on;
begin
  custproc_16047(3);
end;  

create or replace procedure procincr_16047 (p_id in number) as
begin
  update Product_16047 set price=price+0.1*price where product_id=p_id;
exception
  when NO_DATA_FOUND then
    dbms_output.put_line('Product with an id '||p_id||' doesnt exist');  
end procincr_16047;  

begin
  procincr_16047(1);
end;  
select * from Product_16047;

create or replace procedure InsertProduct_16047 (p_id in number , proddesc in varchar2 , price in number) as
begin
  insert into Product_16047 values(p_id,proddesc,price);
exception
  when OTHERS then
    dbms_output.put_line('values cannot be inserted');
end InsertProduct_16047;  

begin
  InsertProduct_16047(3,'electronic',76000);
end;  

create or replace trigger triginsupd_16047 
after insert or update on customer_16047
for each row
begin
  dbms_output.put_line('customer_id is '||:new.cust_id);
end triginsupd_16047;  

begin
  insert into customer_16047 values(13,'onkar','onka67@gmail.com',655613799,'magarpatta pune');
end;

create or replace trigger trigdel_16047 
after DELETE on customer_16047
for each row
begin
  dbms_output.put_line('customer_id is '||:old.cust_id||' and name is '||:old.cust_name);
end trigdel_16047; 

begin
  delete from customer_16047 where cust_id=13;
end;
select * from Product_16047;

select * from employee_16047;
create table employee_16047(
  emp_id number(4),
  emp_name varchar2(40),
  dept_id number(3)
  );

insert into employee_16047 values(2,'onkar',12);

create or replace procedure  getempdetails_16047 (deptid in number , empid out number , empname out varchar ) as
begin
  select emp_id,emp_name into empid,empname from employee_16047 where dept_id=deptid;
end getempdetails_16047;  

create or replace procedure getUserList ( empname in varchar , p_dbuser out SYS_REFCURSOR ) as
begin
  open p_dbuser for select * from employee_16047 where emp_name like empname||'%';
end getUserList;  
select * from employee_16047;
insert into employee_16047 values(3,'paryush',13);

create table Prod_16047(
prodid varchar(20),
prodname varchar(30),
quantity number(3),
price number(9,2),
typeofproduct varchar(20),
expirydate date,
categoryofproduct varchar(30)

);

create or replace procedure getAllProductDetails_16047(p_info out SYS_REFCURSOR) as
begin
  open p_info for select * from Prod_16047;
end getAllProductDetails_16047;  

create or replace procedure insertProduct_16047 (pid in varchar , pname in varchar , q in number , p in number , typ in varchar , d in date , cat in varchar ) as
begin
  insert into Prod_16047 values(pid,pname,q,p,typ,d,cat);
end insertProduct_16047;  

create or replace procedure del_16047 (pid in varchar) as
begin
  delete from Prod_16047 where prodid=pid;
end del_16047;  


create or replace procedure updateProduct_16047 ( pid in varchar , param in varchar , typ in number) as
begin
  if typ = 1 then
     update Prod_16047 set prodname=param where prodid=pid;
  elsif typ = 2 then
     update Prod_16047 set quantity=TO_NUMBER(param) where prodid=pid;
  elsif typ = 3 then
     update Prod_16047 set price=TO_NUMBER(param) where prodid=pid;
  end if;
end updateProduct_16047;  

select * from Prod_16047;


create table login_16047
(
  cust_id number(4),
  username varchar(50),
  pass_word varchar(50) 

);