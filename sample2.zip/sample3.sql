create or replace procedure verifyemailpass_16047 ( email in varchar , pass in varchar,flag out number,ctype out varchar , customerid out number) as
begin
  select custtype,cid into ctype,customerid from cust_16047 where custemail=email and custpass=pass;
  flag:=1;
Exception
  when NO_DATA_FOUND then
  begin
     flag:=0;
     ctype:=null;
     customerid:=-1;
  end;   
  
  select * from Productinfo_16047;

end verifyemailpass_16047;

select * from cust_16047;

select * from productcustinfo_16047;

create table Productnew_16047 (
    prod_id number(4) primary key,
    prod_name varchar(40),
    pro_description varchar(50),
    prod_exp_date date,
    prod_perishable varchar(40),
    catid number(4)
);

commit;
select * from productcustinfo_16047;
insert into Productnew_16047 values(2,'coca cola','colddrink',TO_DATE('18-JAN-2020'),'1',13);

create or replace procedure deleteproduct_16047 (pname in varchar) as
begin
  delete from Productinfo_16047 where prodname=pname;
end deleteproduct_16047;  

select * from Productnew_16047;


create or replace procedure getproddetails_16047(pname in varchar,pdesc out varchar,prate out number) as
begin
  select proddesc,prodrate into pdesc,prate from Productinfo_16047 where prodname=pname;
end getproddetails_16047;  