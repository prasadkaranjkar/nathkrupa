create table Persontab_16047(
 
 id number(5),
 firstname varchar(50),
 lastname varchar(50)

);
commit;

select * from Persontab_16047;
delete from Productinfo_16047;

select * from Productinfo_16047;
select * from paymentcard_16047;
select * from productcustinfo_16047;
insert into Productinfo_16047 values('CHRYSOPERLA CARNEA','Chrysoperla carnea, known as the common green lacewing, is an insect in the Chrysopidae family. It is found in many parts of America, Europe and Asia. Although the adults feed on nectar, pollen and aphid honeydew, the larvae are active predators and feed on aphids and other small insects. It has been used in the biological control of insect pests on crops.

Chrysoperla carnea was originally considered to be a single species with a holarctic distribution but it has now been shown to be a complex of many cryptic, sibling subspecies. These are indistinguishable from each other morphologically but can be recognised by variations in the vibrational songs the insects use to communicate with each other, which they especially do during courtship',200);

insert into Productinfo_16047 values('TRICHOGRAMMA CHILONIS','Trichogramma are minute polyphagous wasps that are endoparasitoids of insect eggs.[1] Trichogramma is one of around 80 genera from the family Trichogrammatidae, with over 200 species worldwide.[2][3][4]

Although there are several groups of egg parasitoids commonly employed for biological control throughout the world, Trichogramma have been the most extensively studied.[5] There have been more than a thousand papers published on Trichogramma and they are the most used biological control agents in the world.[6] Trichogramma are unique in approaching the size limit of how small an insect can be, which would be determined by how few neurons they can fit in their central nervous system, yet exhibiting a complex behavior to sustain their life. Trichogramma have less than 10,000 neurons, which is a hundred times fewer than the next smallest insect.',60);