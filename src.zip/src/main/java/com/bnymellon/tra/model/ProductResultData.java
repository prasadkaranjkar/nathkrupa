package com.bnymellon.tra.model;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

import org.springframework.stereotype.Component;

@XmlRootElement(name = "ProductResultData")	
@Component
public class ProductResultData {

	private List<Products> prod = new ArrayList<Products>();

	public ProductResultData() {
		super();
		// TODO Auto-generated constructor stub
	}

	public List<Products> getProducts() {
		return prod;
	}

	public void setEmps(List<Products> prod) {
		this.prod = prod;
	}
	
}