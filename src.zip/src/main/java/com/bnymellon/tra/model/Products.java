package com.bnymellon.tra.model;

import java.util.Currency;
import java.util.Date;

import org.springframework.stereotype.Controller;

@Controller
public class Products {

	private int prodId;
	private String prodName;
	private String prodType;
	private String prodCat;
	private String prodDesc;
	private double prodWeight;
	private String prodColor;
	private int prodQuantity;
	private String prodSupplier;
	private String prodCustomer;
	private Date prodMfdDate;
	private String isAvailable;
	private double prodRate;
	private String prodCountryOfMfd;
	private Currency prodRateInCurrency;
	public Products() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Products [prodId=" + prodId + ", prodName=" + prodName + ", prodType=" + prodType + ", prodCat="
				+ prodCat + ", prodDesc=" + prodDesc + ", prodWeight=" + prodWeight + ", prodColor=" + prodColor
				+ ", prodQuantity=" + prodQuantity + ", prodSupplier=" + prodSupplier + ", prodCustomer=" + prodCustomer
				+ ", prodMfdDate=" + prodMfdDate + ", isAvailable=" + isAvailable + ", prodRate=" + prodRate
				+ ", prodCountryOfMfd=" + prodCountryOfMfd + ", prodRateInCurrency=" + prodRateInCurrency + "]";
	}
	public int getProdId() {
		return prodId;
	}
	public void setProdId(int prodId) {
		this.prodId = prodId;
	}
	public String getProdName() {
		return prodName;
	}
	public void setProdName(String prodName) {
		this.prodName = prodName;
	}
	public String getProdType() {
		return prodType;
	}
	public void setProdType(String prodType) {
		this.prodType = prodType;
	}
	public String getProdCat() {
		return prodCat;
	}
	public void setProdCat(String prodCat) {
		this.prodCat = prodCat;
	}
	public String getProdDesc() {
		return prodDesc;
	}
	public void setProdDesc(String prodDesc) {
		this.prodDesc = prodDesc;
	}
	public double getProdWeight() {
		return prodWeight;
	}
	public void setProdWeight(double prodWeight) {
		this.prodWeight = prodWeight;
	}
	public String getProdColor() {
		return prodColor;
	}
	public void setProdColor(String prodColor) {
		this.prodColor = prodColor;
	}
	public int getProdQuantity() {
		return prodQuantity;
	}
	public void setProdQuantity(int prodQuantity) {
		this.prodQuantity = prodQuantity;
	}
	public String getProdSupplier() {
		return prodSupplier;
	}
	public void setProdSupplier(String prodSupplier) {
		this.prodSupplier = prodSupplier;
	}
	public String getProdCustomer() {
		return prodCustomer;
	}
	public void setProdCustomer(String prodCustomer) {
		this.prodCustomer = prodCustomer;
	}
	public Date getProdMfdDate() {
		return prodMfdDate;
	}
	public void setProdMfdDate(Date prodMfdDate) {
		this.prodMfdDate = prodMfdDate;
	}
	public String isAvailable() {
		return isAvailable;
	}
	public void setAvailable(String isAvailable) {
		this.isAvailable = isAvailable;
	}
	public double getProdRate() {
		return prodRate;
	}
	public void setProdRate(double prodRate) {
		this.prodRate = prodRate;
	}
	public String getProdCountryOfMfd() {
		return prodCountryOfMfd;
	}
	public void setProdCountryOfMfd(String prodCountryOfMfd) {
		this.prodCountryOfMfd = prodCountryOfMfd;
	}
	public Currency getProdRateInCurrency() {
		return prodRateInCurrency;
	}
	public void setProdRateInCurrency(Currency prodRateInCurrency) {
		this.prodRateInCurrency = prodRateInCurrency;
	}
}
