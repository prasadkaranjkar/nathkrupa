package com.bnymellon.tra.model;

import org.springframework.stereotype.Component;

@Component
public class SuccessProductResult implements ProductResult {

	private MetaData metaData;
	private ProductResultData data;
	
		
	public SuccessProductResult() {
		super();
		// TODO Auto-generated constructor stub
	}

	public MetaData getMetaData() {
		return metaData;
	}

	public void setMetaData(MetaData metaData) {
		this.metaData = metaData;
	}

	public ProductResultData getData() {
		return data;
	}

	public void setData(ProductResultData data) {
		this.data = data;
	}	
}
