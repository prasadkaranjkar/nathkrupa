package com.bnymellon.tra.model;

import org.springframework.stereotype.Component;

@Component
public class FailureProductResult implements ProductResult {

	private MetaData metaData;
	private Errors errors;
	
			
	public FailureProductResult() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Errors getErrors() {
		return errors;
	}

	public void setErrors(Errors errors) {
		this.errors = errors;
	}

	public MetaData getMetaData() {
		return metaData;
	}

	public void setMetaData(MetaData metaData) {
		this.metaData = metaData;
	}


}