package com.bnymellon.tra.model;

public interface ProductResult {
	public MetaData getMetaData();
	public void setMetaData(MetaData metaData);
}
