package com.bnymellon.tra.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bnymellon.tra.dao.impl.ProductDao;
import com.bnymellon.tra.model.Errors;
import com.bnymellon.tra.model.FailureProductResult;
import com.bnymellon.tra.model.MetaData;
import com.bnymellon.tra.model.ProductResult;
import com.bnymellon.tra.model.ProductResultData;
import com.bnymellon.tra.model.Products;
import com.bnymellon.tra.model.SuccessProductResult;

@Component
public class ProductServiceImpl {


	@Autowired
	ProductDao productDao;

	@Autowired
	ProductResultData productResultData;

	@Autowired
	SuccessProductResult successProductResult;
	@Autowired
	FailureProductResult failureProductResult;

	@Autowired
	MetaData metaData;
	@Autowired
	Errors errors;
	boolean success = true;
	boolean failure = false;
	
	public ProductResult getAllProducts() {
		List<Products> empList = productDao.getAllProducts();
		if (!empList.isEmpty()) {
			metaData.setSuccess(success);
			metaData.setDescription("List of all Employees");
			metaData.setResponseId("TRA-" + "NX-" + UUID.randomUUID().toString());
			productResultData.setEmps(empList);
			successProductResult.setMetaData(metaData);
			successProductResult.setData(productResultData);
			return successProductResult;

		} else {
			metaData.setSuccess(failure);
			metaData.setDescription("List of all Employees Not found");
			metaData.setResponseId("TRA-" + "NX-" + UUID.randomUUID().toString());
			failureProductResult.setMetaData(metaData);
			errors.setCode("TRA-1001");
			errors.setDescription("No data available at this time");
			failureProductResult.setErrors(errors);
			return failureProductResult;
		}
	}
	
	public ProductResult getProduct(int id) {
		List<Products> empList = new ArrayList<Products>();
		Products products = productDao.getProductById(id);
		if (products != null) {
			empList.add(products);
			metaData.setSuccess(success);
			metaData.setDescription("Found Emp details");
			metaData.setResponseId("TRA-" + "NX-" + UUID.randomUUID().toString());
			productResultData.setEmps(empList);
			successProductResult.setMetaData(metaData);
			successProductResult.setData(productResultData);
			return successProductResult;

		} else {
			metaData.setSuccess(failure);
			metaData.setDescription("Emp details");
			metaData.setResponseId("TRA-" + "NX-" + UUID.randomUUID().toString());
			failureProductResult.setMetaData(metaData);
			errors.setCode("TRA-1001");
			errors.setDescription("Not Emp Details found");
			failureProductResult.setErrors(errors);
			return failureProductResult;
		}
	}

	public ProductResult insertProduct(Products e) {
		List<Products> productList = new ArrayList<Products>();
		Products products = productDao.save(e);
		if (products != null) {
			productList.add(products);
			metaData.setSuccess(success);
			metaData.setDescription("New Emp inserted");
			metaData.setResponseId("TRA-" + "NX-" + UUID.randomUUID().toString());
			productResultData.setEmps(productList);
			successProductResult.setMetaData(metaData);
			successProductResult.setData(productResultData);
			return successProductResult;

		} else {
			metaData.setSuccess(failure);
			metaData.setDescription("New Emp insertion error");
			metaData.setResponseId("TRA-" + "NX-" + UUID.randomUUID().toString());
			failureProductResult.setMetaData(metaData);
			errors.setCode("TRA-1001");
			errors.setDescription("No data available at this time");
			failureProductResult.setErrors(errors);
			return failureProductResult;
		}
	}

	public ProductResult updateProduct(int searchId, Products e) {
		List<Products> productList = new ArrayList<Products>();
		Products product = productDao.update(searchId, e);
		if (product != null) {
			productList.add(product);
			metaData.setSuccess(success);
			metaData.setDescription(searchId+" emp record updated");
			metaData.setResponseId("TRA-" + "NX-" + UUID.randomUUID().toString());
			productResultData.setEmps(productList);
			successProductResult.setMetaData(metaData);
			successProductResult.setData(productResultData);
			return successProductResult;

		} else {
			metaData.setSuccess(failure);
			metaData.setDescription(searchId+" emp record cannot be updated");
			metaData.setResponseId("TRA-" + "NX-" + UUID.randomUUID().toString());
			failureProductResult.setMetaData(metaData);
			errors.setCode("TRA-1002");
			errors.setDescription("No emp exist with id - "+ searchId);
			failureProductResult.setErrors(errors);
			return failureProductResult;
		}
	}

	
	public ProductResult deleteProduct(int id) {
		List<Products> productList = new ArrayList<Products>();
		Products product = productDao.delete(id);
		if (product != null) {
			productList.add(product);
			metaData.setSuccess(success);
			metaData.setDescription(id+" emp record deleted");
			metaData.setResponseId("TRA-" + "NX-" + UUID.randomUUID().toString());
			productResultData.setEmps(productList);
			successProductResult.setMetaData(metaData);
			successProductResult.setData(productResultData);
			return successProductResult;

		} else {
			metaData.setSuccess(failure);
			metaData.setDescription(id+" emp record cannot be deleted");
			metaData.setResponseId("TRA-" + "NX-" + UUID.randomUUID().toString());
			failureProductResult.setMetaData(metaData);
			errors.setCode("TRA-1002");
			errors.setDescription("No emp exist with id - "+ id);
			failureProductResult.setErrors(errors);
			return failureProductResult;
		}

	}
	
}
