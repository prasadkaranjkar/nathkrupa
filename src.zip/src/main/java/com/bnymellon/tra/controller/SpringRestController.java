package com.bnymellon.tra.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bnymellon.tra.model.ProductResult;
import com.bnymellon.tra.model.Products;
import com.bnymellon.tra.service.ProductService;
import com.bnymellon.tra.service.impl.ProductServiceImpl;

@RestController
@CrossOrigin(origins = "*", allowedHeaders = "Origin, Content-Type, X-Auth-Token,X-client-key,X-Requested-With", methods = {
		RequestMethod.GET, RequestMethod.POST,RequestMethod.PUT, RequestMethod.DELETE,RequestMethod.OPTIONS })
public class SpringRestController {

	@Autowired
	ProductServiceImpl productServiceImpl;
	
	@RequestMapping(value = "/products", /*consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE,*/ produces = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE },method=RequestMethod.GET)
	public ProductResult getAllEmployees() {
		return productServiceImpl.getAllProducts();
	}

	@RequestMapping(value = "/products/{id}" ,produces = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE },method=RequestMethod.GET)
	public ProductResult getEmployee(@PathVariable("id") int id) {
		return productServiceImpl.getProduct(id);
	}

	@RequestMapping(value = "/products",method=RequestMethod.POST, consumes = { MediaType.APPLICATION_JSON_VALUE,
			MediaType.APPLICATION_XML_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE,
					MediaType.APPLICATION_XML_VALUE })
	public ProductResult insertEmployee(@RequestBody Products products) {
		return productServiceImpl.insertProduct(products);
	}

	@RequestMapping(value = "/products/{id}", /*consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE,*/ produces = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE },method=RequestMethod.DELETE)
	public ProductResult deleteEmployee(@PathVariable int id) {
		return productServiceImpl.deleteProduct(id);
	}

	@RequestMapping(value = "/employees/{id}", consumes = { MediaType.APPLICATION_JSON_VALUE,
			MediaType.APPLICATION_XML_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE,
					MediaType.APPLICATION_XML_VALUE },method=RequestMethod.PUT)
	public ProductResult updateEmployee(@PathVariable int id, @RequestBody Products product) {
		return productServiceImpl.updateProduct(id, product);
	}

}
