package com.bnymellon.tra.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Currency;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;

import com.bnymellon.tra.model.Products;

@Component
public class ProductDao {

	private JdbcTemplate jdbcTemplate;
	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}
	@Autowired
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	public List<Products>getAllProducts(){
		List<Products>list=jdbcTemplate.query("select * from Productnexen_16047", new RowMapper() {
			 public Object mapRow(ResultSet rs, int row) throws SQLException {
				// TODO Auto-generated method stub
				 Products products=new Products();
				 products.setProdId(rs.getInt(1));
				 products.setProdName(rs.getString(2));
				 products.setProdType(rs.getString(3));
				 products.setProdCat(rs.getString(4));
				 products.setProdDesc(rs.getString(5));
				 products.setProdWeight(rs.getDouble(6));
				 products.setProdColor(rs.getString(7));
				 products.setProdQuantity(rs.getInt(8));
				 products.setProdSupplier(rs.getString(9));
				 products.setProdCustomer(rs.getString(10));
				 products.setProdMfdDate(rs.getDate(11));
				 products.setAvailable(rs.getString(12));
				 products.setProdRate(rs.getDouble(13));
				 products.setProdCountryOfMfd(rs.getString(14));
				 String curr=rs.getString(15);
				 products.setProdRateInCurrency(Currency.getInstance(curr));
				return products;
			}
		});
		return list;
	}
	public Products getProductById(int id){
		String sql="select * from Productnexen_16047 where prodId="+id;
		List<Products>list=jdbcTemplate.query(sql, new RowMapper() {
			 public Object mapRow(ResultSet rs, int row) throws SQLException {
				// TODO Auto-generated method stub
				 Products products=new Products();
				 products.setProdId(rs.getInt(1));
				 products.setProdName(rs.getString(2));
				 products.setProdType(rs.getString(3));
				 products.setProdCat(rs.getString(4));
				 products.setProdDesc(rs.getString(5));
				 products.setProdWeight(rs.getDouble(6));
				 products.setProdColor(rs.getString(7));
				 products.setProdQuantity(rs.getInt(8));
				 products.setProdSupplier(rs.getString(9));
				 products.setProdCustomer(rs.getString(10));
				 products.setProdMfdDate(rs.getDate(11));
				 products.setAvailable(rs.getString(12));
				 products.setProdRate(rs.getDouble(13));
				 products.setProdCountryOfMfd(rs.getString(14));
				 String curr=rs.getString(15);
				 products.setProdRateInCurrency(Currency.getInstance(curr));
				return products;
			}
		});
		if(list.isEmpty()){
			return null;
		}
		else{
			return list.get(0);
		}
	}
	
	
	public Products save(Products products){
		String sql = "insert into Productnexen_16047 values(" + products.getProdId() + ",'" + products.getProdName() + "','"
				+ products.getProdType() + "','" + products.getProdCat() + "','"+products.getProdDesc()+"',"+products.getProdWeight()+",'"+products.getProdColor()+"',"
				+products.getProdQuantity()+",'"+products.getProdSupplier()+"','"+products.getProdCustomer()+"',"+products.getProdMfdDate()+","+products.isAvailable()+","+products.getProdRate()+",'"+products.getProdCountryOfMfd()+"','"+products.getProdRateInCurrency().toString()+"')";
		System.out.println(sql);
		jdbcTemplate.update(sql);
		return getProductById(products.getProdId());
	}
	
	public Products delete(int id) {
		String sql = "delete from Productnexen_16047 where prodId=" + id;
		System.out.println(sql);
		Products temp = getProductById(id);
		if (jdbcTemplate.update(sql) > 0) {
			return temp;
		} else {
			return null;
		}
	}
	
	public Products update(int searchId, Products p) {
		String sql = "update Productnexen_16047 set id=" + p.getProdId() + ", prodName='" + p.getProdName() + "', prodType='" + p.getProdType()
				+ "', prodCat='" + p.getProdCat() + "' where id=" + searchId + "";
		System.out.println(sql);
		Products temp = getProductById(searchId);
		if (jdbcTemplate.update(sql) > 0) {
			return temp;
		} else {
			return null;
		}

	}
}
