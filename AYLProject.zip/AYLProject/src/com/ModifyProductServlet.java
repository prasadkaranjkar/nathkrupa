package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ModifyProductServlet extends HttpServlet{
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
	//	super.doPost(req, resp);
		resp.setContentType("text/html");
		PrintWriter out=resp.getWriter();

		DatabaseService ds=new DatabaseService();
		Connection conn=ds.getConnection();
		String values[]=req.getParameterValues("products");
		String orgvalues[]=new String[values.length];
		for(int i=0;i<values.length;i++){
			char arr[]=values[i].toCharArray();
			for(int j=0;j<arr.length;j++) {
				if(arr[j]==',')
					arr[j]=' ';
			}
			String npname=new String(arr);
			orgvalues[i]=npname;
		}
		ArrayList<ProductDetails>array=new ArrayList<ProductDetails>();
		for(int i=0;i<values.length;i++){
			try{
			CallableStatement cs=conn.prepareCall("{ call getproddetails_16047(?,?,?) }");
			cs.setString(1, orgvalues[i]);
			cs.registerOutParameter(2, Types.VARCHAR);
			cs.registerOutParameter(3, Types.INTEGER);
			cs.executeQuery();
			ProductDetails pd=new ProductDetails(orgvalues[i], cs.getString(2), cs.getInt(3));
			array.add(pd);
		  }catch(SQLException e){
			  e.printStackTrace();
		  }
		}		
		req.setAttribute("productdetails", array);
		RequestDispatcher rd=req.getRequestDispatcher("displaymodifyproduct.jsp");
		rd.forward(req, resp);
	}

}
