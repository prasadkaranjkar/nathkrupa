package com;

public class ProductDetails {

	private String prodName;
	private String prodDesc;
	private int prodRate;
	public String getProdName() {
		return prodName;
	}
	public void setProdName(String prodName) {
		this.prodName = prodName;
	}
	public String getProdDesc() {
		return prodDesc;
	}
	public ProductDetails(String prodName, String prodDesc, int prodRate) {
		super();
		this.prodName = prodName;
		this.prodDesc = prodDesc;
		this.prodRate = prodRate;
	}
	public void setProdDesc(String prodDesc) {
		this.prodDesc = prodDesc;
	}
	public int getProdRate() {
		return prodRate;
	}
	public void setProdRate(int prodRate) {
		this.prodRate = prodRate;
	}
	
}
