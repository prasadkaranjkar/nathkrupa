package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class RegisterServlet extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
	//	super.doPost(req, resp);
		resp.setContentType("text/html");
		PrintWriter out=resp.getWriter();
		String username=req.getParameter("uname");
		String email=req.getParameter("emaddr");
		long mob=Long.parseLong(req.getParameter("contactno"));
		String addr=req.getParameter("address");
		String country=req.getParameter("country");
		String password=req.getParameter("pword");
		String securityans=req.getParameter("secans");
		DatabaseService ds=new DatabaseService();
		Connection conn=ds.getConnection();
		if(conn!=null) {
			
			try {
				CallableStatement cs=conn.prepareCall("{ call storecustinfo_16047(?,?,?,?,?,?,?) }");
				cs.setString(1, username);
				cs.setString(2, email);
				cs.setLong(3, mob);
				cs.setString(4, addr);
				cs.setString(5, country);
				cs.setString(6, password);
				cs.setString(7, securityans);
				int n=cs.executeUpdate();
				if(n>0) {
					
					RequestDispatcher rd=req.getRequestDispatcher("regresponse.html");
					rd.include(req, resp);
					
					out.close();
				}
				else {
					RequestDispatcher rd=req.getRequestDispatcher("failregresponse.html");
					rd.include(req, resp);
					
					out.close();
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}
}
