package com;

import java.io.IOException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;
import java.text.SimpleDateFormat;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.sun.org.apache.xerces.internal.impl.xpath.regex.ParseException;

public class PaymentServlet extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
	//	super.doPost(req, resp);
		DatabaseService ds=new DatabaseService();
		Connection conn=ds.getConnection();
		if(conn!=null) {
			try {
				HttpSession hs=req.getSession();
				int sum=(Integer)hs.getAttribute("amount");
			    SimpleDateFormat sdf=new SimpleDateFormat("yyyy-mm-dd");
				java.util.Date du;
				System.out.println(req.getParameter("carddate"));
				CallableStatement cs=conn.prepareCall("{ call verifypayinfo_16047(?,?,?,?,?) }");
				cs.setString(1, req.getParameter("cardname"));
				cs.setLong(2, Long.parseLong(req.getParameter("cardnumber")));
				cs.setInt(3, Integer.parseInt(req.getParameter("cardcode")));
				cs.setInt(4, sum);
				cs.registerOutParameter(5, Types.INTEGER);
				cs.executeUpdate();
				int flag=cs.getInt(5);
				if(flag==1){
					RequestDispatcher rd=req.getRequestDispatcher("PaymentSuccess.jsp");
					rd.forward(req, resp);
				}
			}catch(SQLException e){
				e.printStackTrace();
			}
		
	}
	
}
}
