package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class UpdateProductServlet extends HttpServlet {
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
//		super.doPost(req, resp);
		resp.setContentType("text/html");
		PrintWriter out=resp.getWriter();

		DatabaseService ds=new DatabaseService();
		Connection conn=ds.getConnection();
		HttpSession hs=req.getSession();
	//	ArrayList<ProductDetails>array=(ArrayList<ProductDetails>)req.getAttribute("productdetails");
		int j;
		int i=(Integer)hs.getAttribute("rows");
		//System.out.println(req.getAttribute("rows"));
		CallableStatement cs;
		for(j=1;j<i;j++){
			String p="addp"+Integer.toString(j);
			String pname=req.getParameter(p);
			char arr[]=pname.toCharArray();
			for(int k=0;k<arr.length;k++) {
				if(arr[k]==',')
					arr[k]=' ';
			}
			String npname=new String(arr);
			System.out.println(npname);
			String d="descp"+Integer.toString(j);
			String pdesc=req.getParameter(d);
			String r="ratep"+Integer.toString(j);
			String prate=req.getParameter(r);
			try {
				cs=conn.prepareCall("{ call updateproductinfo_16047(?,?,?) }");
				cs.setString(1, npname);
				cs.setString(2, pdesc);
				cs.setString(3, prate);
				cs.executeUpdate();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		RequestDispatcher rd=req.getRequestDispatcher("updatesuccess.jsp");
		rd.forward(req, resp);
		
	}

}
