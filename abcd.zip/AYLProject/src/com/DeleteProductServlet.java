package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class DeleteProductServlet extends HttpServlet{
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
	//	super.doPost(req, resp);
		DatabaseService ds=new DatabaseService();
		Connection conn=ds.getConnection();
		resp.setContentType("text/html");
		PrintWriter out=resp.getWriter();
		String val[]=req.getParameterValues("products");
		
		try {
			
			for(String str:val) {
				if(str!=null) {
			CallableStatement cs=conn.prepareCall("{ call deleteproduct_16047(?) }");
			cs.setString(1, str);
			cs.executeUpdate();				}
			}		
			out.println("<h2>done</h2>");
		}catch(SQLException e) {
			e.printStackTrace();
		}
	}

}
