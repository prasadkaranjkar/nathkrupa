package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ForgotServlet extends HttpServlet {
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
	//	super.doPost(req, resp);
		resp.setContentType("text/html");
		PrintWriter out=resp.getWriter();
		String email=req.getParameter("email");
		String securityans=req.getParameter("secans");
		DatabaseService ds=new DatabaseService();
		Connection conn=ds.getConnection();
		if(conn!=null) {
			try {
				CallableStatement cs=conn.prepareCall("{ call forgotpassproc_16047(?,?,?) }");
				cs.setString(1,email);
				cs.setString(2, securityans);
				cs.registerOutParameter(3, Types.VARCHAR);
				cs.executeUpdate();
				String pass=cs.getString(3);
				if(pass!=null) {
					req.setAttribute("password", pass);
					RequestDispatcher rd=req.getRequestDispatcher("forgotpassword.jsp");
					rd.forward(req, resp);
					
					
				}
				else {
					RequestDispatcher rd=req.getRequestDispatcher("failforgotpassword.html");
					rd.include(req, resp);
					
					//out.close();
				}
	      }catch(Exception e) {
	    	  e.printStackTrace();
	      }

    }
  }
}	
