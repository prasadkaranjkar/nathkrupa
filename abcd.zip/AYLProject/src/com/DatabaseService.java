package com;

import java.sql.Connection;
import java.sql.DriverManager;

public class DatabaseService {

	private static Connection conn=null;
	public Connection getConnection() {
		try {
			DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
			String url="jdbc:oracle:thin:@10.232.71.29:1521:INATP02";
			conn=DriverManager.getConnection(url,"shobana","shobana");	
    	    return conn;
			
		}catch(Exception e) {
			e.printStackTrace();
			return conn;
		}
	}
	
}