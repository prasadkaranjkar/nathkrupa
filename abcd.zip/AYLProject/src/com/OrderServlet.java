package com;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class OrderServlet extends HttpServlet{
	
	 @Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
	//	super.doPost(req, resp);
		 resp.setContentType("text/html");
		 int prod1=0,prod2=0;
		 PrintWriter out=resp.getWriter();
		 String names[]=req.getParameterValues("product");
		 String values[]=req.getParameterValues("products");
		 for(int i=0;i<names.length;i++) {
			 if(names[i]!=null) {
				 
			 }
		 }
		 RequestDispatcher rd=req.getRequestDispatcher("productamount.jsp");
		 rd.forward(req, resp);
		 out.close();
	}

}