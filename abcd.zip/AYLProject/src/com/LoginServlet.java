package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import oracle.jdbc.OracleTypes;

public class LoginServlet extends HttpServlet{

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
	//	super.doPost(req, resp);
		resp.setContentType("text/html");
		PrintWriter out=resp.getWriter();
		String email=req.getParameter("email");
		String password=req.getParameter("pword");
//	HttpSession hs=req.getSession();
	//	hs	.setAttribute("em", email);
		//hs.setAttribute("pass", password);
		
		DatabaseService ds=new DatabaseService();
		Connection conn=ds.getConnection();
		if(conn!=null) {
			try {
				CallableStatement cs=conn.prepareCall("{ call verifyemailpass_16047(?,?,?,?,?) }");
				cs.setString(1,email);
				cs.setString(2,password);
				cs.registerOutParameter(3,Types.INTEGER);
				cs.registerOutParameter(4, Types.VARCHAR);
				cs.registerOutParameter(5, Types.INTEGER);
				cs.executeUpdate();
				int flag=cs.getInt(3);
				String type=cs.getString(4);
				if(flag==1) {
					if(type.equals("User")){
					HttpSession hs=req.getSession();
					hs.setAttribute("em", email);
					hs.setAttribute("pass", password);
					int cid=cs.getInt(5);
					hs.setAttribute("custid", cid);
				    CallableStatement cs2=conn.prepareCall("{ call getallproduct_16047(?) }");
                    cs2.registerOutParameter(1, OracleTypes.CURSOR);
                    cs2.executeQuery();
                    ResultSet rs=(ResultSet)cs2.getObject(1);
                    req.setAttribute("ProductList", rs);
					RequestDispatcher rd=req.getRequestDispatcher("index.jsp");
					rd.forward(req, resp);
					}	
					else{
						HttpSession hs=req.getSession();
						hs.setAttribute("em", email);
						hs.setAttribute("pass", password);
						 CallableStatement cs2=conn.prepareCall("{ call getallproduct_16047(?) }");
		                    cs2.registerOutParameter(1, OracleTypes.CURSOR);
		                    cs2.executeQuery();
		                    ResultSet rs=(ResultSet)cs2.getObject(1);
		                    hs.setAttribute("ProductList", rs);
						RequestDispatcher rd=req.getRequestDispatcher("addproduct.jsp");
						rd.include(req, resp);
					}
				}		
				else {
					RequestDispatcher rd=req.getRequestDispatcher("failloginresponse.html");
					rd.include(req, resp);
					
					out.close();
					
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}
}