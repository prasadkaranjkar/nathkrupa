package com;

import java.io.IOException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class ProductServlet extends HttpServlet{
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
	   doGet(req, resp);
		
		
	}
   
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession hs=req.getSession();
		DatabaseService ds=new DatabaseService();
		Connection conn=ds.getConnection();
		String pname=req.getParameter("name");
		char arr[]=pname.toCharArray();
		for(int i=0;i<arr.length;i++) {
			if(arr[i]==',')
				arr[i]=' ';
		}
		String npname=new String(arr);
		try {
			CallableStatement cs=conn.prepareCall("{ call getprodname_16047(?,?) }");
			cs.setString(1, npname);
			cs.registerOutParameter(2, Types.VARCHAR);
			cs.executeQuery();
			String desc=cs.getString(2);
			req.setAttribute("ProductDesc", desc);
			RequestDispatcher rd=req.getRequestDispatcher("product.jsp");
			rd.forward(req, resp);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}