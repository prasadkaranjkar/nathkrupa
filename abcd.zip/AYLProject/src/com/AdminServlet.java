package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import oracle.jdbc.OracleTypes;

public class AdminServlet extends HttpServlet {
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
	//	super.doGet(req, resp);
		resp.setContentType("text/html");
		PrintWriter out=resp.getWriter();

		DatabaseService ds=new DatabaseService();
		Connection conn=ds.getConnection();
		int select=Integer.parseInt(req.getParameter("select"));
	    CallableStatement cs2;
		try {
			cs2 = conn.prepareCall("{ call getallproduct_16047(?) }");
			cs2.registerOutParameter(1, OracleTypes.CURSOR);
		    cs2.executeQuery();
		    ResultSet rs=(ResultSet)cs2.getObject(1);
		    HttpSession hs=req.getSession();
		    hs.setAttribute("ProductList", rs);
		    if(select==1) {
		    	RequestDispatcher rd=req.getRequestDispatcher("addproduct.jsp");
		    	rd.forward(req, resp);
		    }
		    if(select==2) {
		    	RequestDispatcher rd=req.getRequestDispatcher("modifyproduct.jsp");
		        rd.forward(req, resp);
		    }
		    if(select==3) {
		    	RequestDispatcher rd=req.getRequestDispatcher("deleteproduct.jsp");
		    	rd.forward(req, resp);
		    }
		    if(select==4) {
		    	RequestDispatcher rd=req.getRequestDispatcher("addproduct.jsp");
		    	rd.forward(req, resp);
		    }
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
       
	}

}